这个问题是上一个问题的加强版，也不是很强。init表面主角有两题路径可以选择，一条是
town-field-castle，一条是town-river-castle。但是其中一条有守卫，只能从另外一条过去了。
domain文件变化不大。